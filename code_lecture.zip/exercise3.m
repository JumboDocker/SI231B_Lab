clear;
clc;

Lam = [7, 5, 2, 4, 1];
n = length(Lam);

rng(2024);
X = rand(n);
A = (X * diag(Lam)) / X;
I = eye(n);

niters = 6;

% TODO: initialization
% 初始化随机向量（确保所有特征向量的分量都不为0）
q = randn(n, 1);
q = q / norm(q);  % 归一化

% 计算初始Rayleigh商
mu = q' * A * q;

% 存储每个特征值的误差
err = zeros(niters, length(Lam));  % 每行存储一次迭代中各个特征值的误差

% 第一个特征值是最小的，但我们Rayleigh商迭代可能收敛到任意特征值
% 所以计算当前估计与所有特征值的距离
min_err = zeros(niters, 1);  % 存储每次迭代的最小误差

for k = 1 : niters
    % TODO: Rayleigh quotient iteration
    % 解线性系统 (A - mu*I)y = q
    y = (A - mu * I) \ q;
    
    % 归一化得到新的向量
    q = y / norm(y);
    
    % 更新Rayleigh商（特征值估计）
    mu = q' * A * q;
    
    % TODO: record the error in each iteration
    % 计算当前估计mu与所有真实特征值的距离
    current_err = abs(mu - Lam');
    err(k, :) = current_err';
    
    % 找到最小误差
    min_err(k) = min(current_err);
    
    fprintf('Iteration %d: mu = %.6f, min error = %.6e\n', k, mu, min_err(k));
end

% plot
it = 1 : niters;
figure;
semilogy(it, min_err, '-ob', 'LineWidth', 1.5, 'MarkerSize', 8);
xlabel('Iteration');
ylabel('Minimal estimation error (log scale)');
title('Rayleigh Quotient Iteration Convergence');
grid on;

% 显示真实特征值
fprintf('\nTrue eigenvalues: ');
fprintf('%.1f ', Lam);
fprintf('\n');

% 显示最终估计
fprintf('Final estimated eigenvalue: %.6f\n', mu);

% 分析收敛到哪个特征值
[final_min_err, idx] = min(abs(mu - Lam));
fprintf('Converged to eigenvalue %.1f with error %.6e\n', Lam(idx), final_min_err);