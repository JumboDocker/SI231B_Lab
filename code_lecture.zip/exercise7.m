clear; clc;

%% 问题参数
A = [1, 2; 3, 4];
B = [1; 0];
Q = eye(2);
R = 1;

fprintf('代数Riccati方程: A^T X + X A - X B R^{-1} B^T X + Q = 0\n');
fprintf('A = \n'); disp(A);
fprintf('B = \n'); disp(B);
fprintf('Q = \n'); disp(Q);
fprintf('R = %f\n\n', R);

%% 1. 构造哈密顿矩阵
n = size(A, 1);
H = [A, -B*(R\B'); 
     -Q, -A'];

fprintf('哈密顿矩阵 H:\n');
disp(H);

%% 2. 计算实舒尔分解
[U, T] = schur(H, 'real');
fprintf('舒尔分解 H = U*T*U'':\n');
fprintf('U = \n'); disp(U);
fprintf('T = \n'); disp(T);

%% 3. 重新排序，左半平面特征值在左上角
[U_ordered, T_ordered] = ordschur(U, T, 'rhp');
fprintf('重新排序后 T 矩阵（右半平面特征值在左上）:\n');
disp(T_ordered);

%% 4. 提取子空间并求解X
U11 = U_ordered(1:n, 1:n);
U21 = U_ordered(n+1:2*n, 1:n);

X = U21 / U11;  % X = U21 * inv(U11)
X = (X + X') / 2;  % 确保对称

fprintf('\nRiccati方程的解 X:\n');
disp(X);

%% 5. 计算残差
residual = A'*X + X*A - X*B*(R\B')*X + Q;
residual_norm = norm(residual, 'fro');

fprintf('残差矩阵:\n');
disp(residual);
fprintf('残差Frobenius范数: %.6e\n', residual_norm);

%% 6. 验证特征值
eig_H = eig(H);
eig_T = eig(T_ordered);

fprintf('\n验证特征值:\n');
fprintf('哈密顿矩阵特征值: %.6f, %.6f, %.6f, %.6f\n', ...
        real(eig_H(1)), real(eig_H(2)), real(eig_H(3)), real(eig_H(4)));
fprintf('稳定特征值（左半平面）: ');
stable_idx = real(eig_H) < 0;
fprintf('%.6f, %.6f\n', eig_H(stable_idx));