clear;
clc;
Lam = [27, 15, 13, 9, 9, 8];
n = length(Lam);
rng(2024);
X = rand(n);
A = (X * diag(Lam)) / X;

fprintf('矩阵A (%d×%d):\n', n, n);
disp(A);
fprintf('真实特征值: ');
fprintf('%.1f ', Lam);
fprintf('\n\n');

r = 6; % 要计算的特征值/特征向量数量

% 运行正交迭代
[Q, D] = orthogonal_iteration(A, r);

% 显示结果
fprintf('\n=== 正交迭代结果 ===\n');
fprintf('前 %d 个特征向量的正交基 (Q, %d×%d):\n', r, size(Q,1), size(Q,2));
disp(Q);

fprintf('Rayleigh商矩阵 (D, %d×%d):\n', size(D,1), size(D,2));
disp(D);

fprintf('近似特征值 (来自D的对角线):\n');
approx_eigenvalues = diag(D);
disp(approx_eigenvalues');

fprintf('前 %d 个真实特征值:\n', r);
disp(Lam(1:r));

% 计算误差
fprintf('\n=== 误差分析 ===\n');
eig_error = abs(approx_eigenvalues' - Lam(1:r));
fprintf('特征值绝对误差:\n');
for i = 1:r
    fprintf('  λ_%d: %.2e\n', i, eig_error(i));
end

% 检查Q的正交性
if size(Q, 2) == r
    orth_test = Q' * Q;
    orth_error = norm(orth_test - eye(r), 'fro');
    fprintf('\nQ的正交性误差 (||Q''Q - I||_F): %.2e\n', orth_error);
else
    fprintf('\nQ的维度不匹配，无法计算正交性\n');
end

% 验证子空间的不变性
AQ = A * Q;
proj_AQ = Q * (Q' * AQ);
residual_norm = norm(AQ - proj_AQ, 'fro') / norm(AQ, 'fro');
fprintf('不变性误差 (||AQ - Q(Q''AQ)||_F/||AQ||_F): %.2e\n', residual_norm);

% 绘制收敛曲线
figure('Position', [100, 100, 800, 400]);
plot_convergence(A, r);

%% 正交迭代函数
function [Q, D] = orthogonal_iteration(A, r)
    [n, ~] = size(A);
    max_iter = 100;
    tol = 1e-8;
    
    % 初始化随机正交矩阵
    [Q, ~] = qr(randn(n, r), 0);
    
    fprintf('开始正交迭代...\n');
    for iter = 1:max_iter
        Q_old = Q;
        
        % 正交迭代核心步骤
        Y = A * Q;
        [Q, ~] = qr(Y, 0);
        
        % 检查收敛
        diff = eye(r) - Q_old' * Q;
        error = norm(diff, 'fro');
        
        if error < tol
            fprintf('在 %d 次迭代后收敛 (误差 = %.2e)\n', iter, error);
            break;
        end
        
        if iter == max_iter
            fprintf('达到最大迭代次数 %d (最终误差 = %.2e)\n', max_iter, error);
        end
    end
    
    % 计算Rayleigh商矩阵
    D = Q' * A * Q;
    
    % 按特征值大小排序
    [~, idx] = sort(diag(D), 'descend');
    Q = Q(:, idx);
    D = diag(diag(D(idx, idx)));
end

%% 绘制收敛曲线函数
function plot_convergence(A, r)
    [n, ~] = size(A);
    max_iters_plot = 50;
    
    % 运行并记录收敛历史
    Q = qr(randn(n, r), 0);
    errors = zeros(max_iters_plot, 1);
    
    for iter = 1:max_iters_plot
        Q_old = Q;
        Y = A * Q;
        [Q, ~] = qr(Y, 0);
        
        diff = eye(r) - Q_old' * Q;
        errors(iter) = norm(diff, 'fro');
        
        % 记录特征值近似
        if mod(iter, 10) == 0
            D_temp = Q' * A * Q;
            approx_eigs = diag(D_temp);
            fprintf('迭代 %3d: 误差 = %.2e, 特征值 ≈ ', iter, errors(iter));
            fprintf('%.2f ', sort(approx_eigs, 'descend'));
            fprintf('\n');
        end
    end
    
    % 绘制收敛曲线
    subplot(1, 2, 1);
    semilogy(1:max_iters_plot, errors, 'b-', 'LineWidth', 2);
    xlabel('迭代次数');
    ylabel('列空间变化误差 (log)');
    title('正交迭代收敛性');
    grid on;
    
    % 绘制特征值收敛
    subplot(1, 2, 2);
    hold on;
    colors = lines(r);
    Q = qr(randn(n, r), 0);
    eig_history = zeros(max_iters_plot, r);
    
    for iter = 1:max_iters_plot
        Y = A * Q;
        [Q, ~] = qr(Y, 0);
        D_temp = Q' * A * Q;
        eig_history(iter, :) = sort(diag(D_temp), 'descend');
    end
    
    for i = 1:r
        plot(1:max_iters_plot, eig_history(:, i), 'Color', colors(i,:), ...
            'LineWidth', 1.5, 'DisplayName', sprintf('λ_%d', i));
    end
    xlabel('迭代次数');
    ylabel('特征值估计');
    title('特征值收敛过程');
    legend('Location', 'best');
    grid on;
end