% Example usage
A = [4, 1, 6, 3;
     2, 5, 8, 7;
     1, 1, 6, 2;
     9, 3, 2, 1];

H = hessenberg_reduction(A);
disp('Hessenberg matrix H:');
disp(H);

% 验证A和H的特征值相同
fprintf('\n验证特征值:\n');
eig_A = eig(A);
eig_H = eig(H);
fprintf('A的特征值: ');
fprintf('%.6f ', sort(eig_A));
fprintf('\nH的特征值: ');
fprintf('%.6f ', sort(eig_H));
fprintf('\n最大特征值差异: %.6e\n', max(abs(sort(eig_A) - sort(eig_H))));

%%
function H = hessenberg_reduction(A)
    % A: Input square matrix
    % H: Hessenberg matrix
    
    [n, m] = size(A);
    if n ~= m
        error('Matrix A must be square');
    end
    
    H = A;
    
    for k = 1:n-2
        % 提取第k列的k+1:n部分
        x = H(k+1:n, k);
        
        % 计算Householder向量v
        v = x;
        
        % 计算符号和范数
        sigma = sign(x(1)) * norm(x);
        v(1) = v(1) + sigma;
        
        % 避免除以0
        beta = v(1)/sigma;
        if abs(sigma) > eps
            v = v / v(1);
        else
            v = zeros(size(v));
            beta = 0;
        end
        
        % 应用Householder变换从左侧
        % H(k+1:n, k:n) = H(k+1:n, k:n) - beta * v * (v' * H(k+1:n, k:n))
        H(k+1:n, k:n) = H(k+1:n, k:n) - beta * v * (v' * H(k+1:n, k:n));
        
        % 应用Householder变换从右侧（保持相似性）
        % H(1:n, k+1:n) = H(1:n, k+1:n) - beta * (H(1:n, k+1:n) * v) * v'
        H(1:n, k+1:n) = H(1:n, k+1:n) - beta * (H(1:n, k+1:n) * v) * v';
    end
end