clear;
clc;
% construct A with given eigenvalues and eigenvectors

Lam = [7, 5, 2, 4, 1];
n = length(Lam);

rng(2024);
X = rand(n);
A = (X * diag(Lam)) / X;
I = eye(n);

A
X(:,2)

niters = 100;

% TODO: initialization
% Choose a shift μ close to the target eigenvalue 5
% Since we know 5 is between 7 and 2, we can choose μ = 5 or slightly different
mu = 5.2;  % Shift slightly above 5 to favor convergence to eigenvalue 5

% Initialize with a random vector
x = rand(n, 1);
x = x / norm(x);  % Normalize

for k = 1 : niters
    % TODO: inverse iteration
    % Solve (A - μI)y = x for y
    y = (A - mu * I) \ x;
    
    % Update x to be the normalized y
    x = y / norm(y);
    
    % Estimate the eigenvalue using Rayleigh quotient
    lambda = x' * A * x;
    
    fprintf('Iteration %d: Estimated eigenvalue = %.6f\n', k, lambda);
end

x
lambda

% Compare with the true eigenvector (X(:,2) corresponds to eigenvalue 5)
true_vec = X(:,2);
true_vec = true_vec / norm(true_vec);  % Normalize for comparison

% Check alignment with true eigenvector
alignment = abs(x' * true_vec);
fprintf('\nFinal estimated eigenvalue: %.6f\n', lambda);
fprintf('True eigenvalue (5): %.6f\n', 5);
fprintf('Error in eigenvalue: %.6e\n', abs(lambda - 5));
fprintf('Alignment with true eigenvector (|x''*v|): %.6f\n', alignment);