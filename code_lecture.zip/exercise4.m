clear; clc;

% 生成矩阵
Lam = [7, 5, 2, 4, 1];
n = length(Lam);
rng(2026);
X = rand(n);
A = (X * diag(Lam)) / X;
I = eye(n);

fprintf('真实特征值: ');
fprintf('%.2f ', Lam);
fprintf('\n\n');

niters = 10; % 幂法和逆迭代需要更多迭代
rqi_iters = 5; % RQI收敛快

% 1. 幂法 + 收缩
fprintf('=== 幂法 (Power Method) ===\n');
A_power = A;
eig_power = zeros(n,1);
vec_power = zeros(n,n);

for i = 1:n
    q = randn(n,1); q = q/norm(q);
    
    for k = 1:niters
        q = A_power * q;
        q = q / norm(q);
    end
    
    lambda = q' * A_power * q;
    eig_power(i) = lambda;
    vec_power(:,i) = q;
    
    fprintf('特征值 %d: %.6f\n', i, lambda);
    
    % 收缩
    if i < n
        A_power = A_power - lambda * (q*q');
    end
end

% 2. 逆迭代 + 收缩  
fprintf('\n=== 逆迭代 (Inverse Iteration) ===\n');
A_inv = A;
eig_inv = zeros(n,1);
vec_inv = zeros(n,n);

% 设置shift - 基于已知特征值大致范围
mu_vals = [6.7, 4.7, 3.3, 1.7, 0.7];

for i = 1:n
    q = randn(n,1); q = q/norm(q);
    mu = mu_vals(i); % 使用预设shift
    
    for k = 1:niters
        q = (A_inv - mu*I) \ q;
        q = q / norm(q);
    end
    
    lambda = q' * A_inv * q;
    eig_inv(i) = lambda;
    vec_inv(:,i) = q;
    
    fprintf('特征值 %d: %.6f (μ=%.2f)\n', i, lambda, mu);
    
    % 收缩
    if i < n
        A_inv = A_inv - lambda * (q*q');
    end
end

% 3. Rayleigh商迭代 + 收缩
fprintf('\n=== Rayleigh商迭代 (RQI) ===\n');
A_rqi = A;
eig_rqi = zeros(n,1);
vec_rqi = zeros(n,n);

for i = 1:n
    q = randn(n,1); q = q/norm(q);
    mu = q' * A_rqi * q; % 初始Rayleigh商
    
    for k = 1:rqi_iters
        try
            q = (A_rqi - mu*I) \ q;
        catch
            q = (A_rqi - mu*I + 1e-10*I) \ q; % 处理奇异
        end
        q = q / norm(q);
        mu = q' * A_rqi * q; % 更新Rayleigh商
    end
    
    lambda = mu;
    eig_rqi(i) = lambda;
    vec_rqi(:,i) = q;
    
    fprintf('特征值 %d: %.6f\n', i, lambda);
    
    % 收缩
    if i < n
        A_rqi = A_rqi - lambda * (q*q');
    end
end

% 结果比较
fprintf('\n\n=== 结果对比 ===\n');
fprintf('方法        特征值结果\n');
fprintf('真实        ');
fprintf('%7.4f ', sort(Lam));
fprintf('\n幂法        ');
fprintf('%7.4f ', sort(eig_power));
fprintf('\n逆迭代      ');
fprintf('%7.4f ', sort(eig_inv));
fprintf('\nRQI         ');
fprintf('%7.4f ', sort(eig_rqi));
fprintf('\n');

% 收敛不确定性演示,随机的初始化q会让算法收敛到不同的特征值
fprintf('\n=== RQI收敛不确定性演示 ===\n');
test_num = 10;
converged_to = zeros(test_num,1);

for test = 1:test_num
    q = randn(n,1); q = q/norm(q);
    mu = q' * A * q;
    
    for k = 1:rqi_iters
        q = (A - mu*I) \ q;
        q = q / norm(q);
        mu = q' * A * q;
    end
    
    [~, idx] = min(abs(mu - Lam));
    converged_to(test) = Lam(idx);
    fprintf('测试 %2d: 初始μ=%.3f → 收敛到λ=%.1f\n', test, q'*A*q, converged_to(test));
end

% 可视化
figure('Position', [100,100,800,600]);

% 特征值误差对比
subplot(2,2,1);
err_power = abs(sort(eig_power) - sort(Lam)');
err_inv = abs(sort(eig_inv) - sort(Lam)');
err_rqi = abs(sort(eig_rqi) - sort(Lam)');

bar(1:n, [err_power, err_inv, err_rqi]);
xlabel('特征值序号');
ylabel('绝对误差');
title('各方法特征值误差');
legend('幂法', '逆迭代', 'RQI', 'Location', 'northwest');
grid on;

% RQI收敛不确定性
subplot(2,2,2);
histogram(converged_to, 'BinEdges', 0.5:1:7.5);
xlabel('收敛到的特征值');
ylabel('频数');
title('RQI收敛不确定性');
grid on;

% 收敛速度对比
subplot(2,2,3);
q0 = randn(n,1); q0 = q0/norm(q0);

% 幂法收敛
q = q0;
power_err = zeros(30,1);
for k = 1:30
    q = A * q; q = q/norm(q);
    mu = q' * A * q;
    power_err(k) = min(abs(mu - Lam));
end

% 逆迭代收敛 (使用合适的shift，这里用5.5接近特征值5)
q = q0; mu = 5.5; % shift选择接近某个特征值
inv_err = zeros(30,1);
for k = 1:30
    q = (A - mu*I) \ q; q = q/norm(q);
    current_mu = q' * A * q;
    inv_err(k) = min(abs(current_mu - Lam));
end

% RQI收敛
q = q0; mu = q' * A * q;
rqi_err = zeros(10,1);
for k = 1:10
    q = (A - mu*I) \ q; q = q/norm(q);
    mu = q' * A * q;
    rqi_err(k) = min(abs(mu - Lam));
end

semilogy(1:30, power_err, 'b-', 'LineWidth', 2); hold on;
semilogy(1:30, inv_err, 'g-.', 'LineWidth', 2);
semilogy(1:10, rqi_err, 'r--', 'LineWidth', 2);
xlabel('迭代次数');
ylabel('最小误差 (log)');
title('收敛速度对比');
legend('幂法', '逆迭代 (μ=5.5)', 'RQI');
grid on;

% 正交性检查
subplot(2,2,4);
orth_power = norm(vec_power' * vec_power - I, 'fro');
orth_inv = norm(vec_inv' * vec_inv - I, 'fro');
orth_rqi = norm(vec_rqi' * vec_rqi - I, 'fro');

bar([orth_power, orth_inv, orth_rqi]);
set(gca, 'XTickLabel', {'幂法', '逆迭代', 'RQI'});
ylabel('正交性误差');
title('特征向量正交性');
grid on;

% 讨论
fprintf('\n=== 讨论 ===\n');
fprintf('1. 三种方法都能通过收缩技术找到所有特征值\n');
fprintf('2. 主要差异:\n');
fprintf('   - 幂法: 只能按模最大到最小顺序找，收敛慢\n');
fprintf('   - 逆迭代: 需要预设shift，可控制找哪个特征值\n');
fprintf('   - RQI: 收敛最快，但收敛到哪个特征值不确定\n\n');

fprintf('3. Rayleigh商迭代的问题:\n');
fprintf('   a) 收敛不确定性: 依赖初始向量，可能收敛到任意特征值\n');
fprintf('   b) 数值稳定性: A-μI接近奇异时求解不稳定\n');
fprintf('   c) 收缩累积误差: 每次收缩引入误差影响后续计算\n\n');

fprintf('4. 收缩技术的局限性:\n');
fprintf('   - 误差会累积\n');
fprintf('   - 仅适用于对称矩阵（保证特征向量正交）\n');
fprintf('   - 对于非对称矩阵效果不佳\n');