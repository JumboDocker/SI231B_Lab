clear;
clc;
% construct A with given eigenvalues and eigenvectors

Lam = [7, 5, 2, 4, 1];
n = length(Lam);

rng(2024);
X = rand(n);
A = (X * diag(Lam)) / X;

A
X(:,1)

niters = 10;

% % TODO: initialization
% for k = 1 : niters
%     % TODO: write the power iteration code
% end

% TODO: initialization
% Initialize with a random vector
b = rand(n, 1);
% Normalize the initial vector
b = b / norm(b);

for k = 1 : niters
    % TODO: write the power iteration code
    % Apply the matrix A to the current vector
    w = A * b;
    
    % Estimate the eigenvalue (Rayleigh quotient)
    lambda = b' * w;
    
    % Normalize the vector for next iteration
    b = w / norm(w);
    
    % Display progress
    fprintf('Iteration %d: Estimated eigenvalue = %.6f\n', k, lambda);
end

% Final results
fprintf('\nFinal estimated eigenvalue: %.6f\n', lambda);
fprintf('True largest eigenvalue: %.6f\n', 7);
fprintf('Error in eigenvalue: %.6e\n', abs(lambda - 7));

% Compare with the true eigenvector (scaled version of X(:,1))
% Note: eigenvectors are only determined up to a scaling factor
true_vec = X(:,1);
true_vec = true_vec / norm(true_vec); % Normalize for comparison

% Check if b aligns with true eigenvector (dot product close to ±1)
alignment = abs(b' * true_vec);
fprintf('Alignment with true eigenvector: %.6f\n', alignment);

